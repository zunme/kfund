insert into z_invest_sunap_detail
(i_id, loan_id, history_idx, paystatus, o_count, sale_id, rate, i_pay,i_pay_remain, wongum, days , interest, withholding , withholdingPayed, total_interest, emoney)
(select i_id, loan_id, 4 as history_idx, 'Y' as paytatus, '0' as o_count
, m_id as sale_id , i_profit_rate as rate
, i_pay , 0 as i_pay_remain
, i_pay as wongum , days , round(i_pay * i_profit_rate/100/365*days) as interest
, '0.275' as withholding
, floor(round(i_pay * i_profit_rate/100/365*days) * 0.275 /10) * 10 as withholdingPayed
, round(i_pay * i_profit_rate/100/365*days) as total_interest
, round(i_pay * i_profit_rate/100/365*days) - ( floor(round(i_pay * i_profit_rate/100/365*days) * 0.275 /10) * 10 ) as emoney
from 
(select 
a.i_id, loan_id , a.m_id,i_pay,i_profit_rate,  datediff( '2018-10-29', i_regdatetime) as days  
from mari_invest a
where loan_id=18) tmp)